import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'resturant';
  resturantList:any[]=[];

  constructor(private http: HttpClient){

  }

  sendTheNumber(number:number|string){
    console.log("VLUE :",number);

  }


  sort({key:-1}).limit();
}
